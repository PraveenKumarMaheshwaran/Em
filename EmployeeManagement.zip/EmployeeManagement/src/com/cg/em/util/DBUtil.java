package com.cg.em.util;


import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.em.exception.EmployeeException;

public class DBUtil {

	static Connection con;
	static String errorMessage;
	static
	{
		try{
			InitialContext context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/jdbc/TestDS");
			con=source.getConnection();		
		}
		catch(NamingException | SQLException e)
		{
			try{
			throw new EmployeeException(e.getMessage());
			
		}
		catch(EmployeeException e1)
		{
			errorMessage=e1.getMessage();
		}
		}
	}
	public static Connection getConnect() 
	{
		return con;
	}

}


