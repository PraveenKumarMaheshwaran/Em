package com.cg.em.service;

import java.util.ArrayList;

import com.cg.em.bean.EmployeeBean;
import com.cg.em.dao.EmployeeDao;
import com.cg.em.dao.EmployeeDaoImpl;
import com.cg.em.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDao dao;
	public EmployeeServiceImpl(){
		dao=new EmployeeDaoImpl();
		
	}

	@Override
	public ArrayList<EmployeeBean> getAllData() throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.getAllData();
	}

	@Override
	public EmployeeBean updateSalary(int empId, int salary)
			throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.updateSalary(empId,salary);
	}

	@Override
	public EmployeeBean deleteEmp(int empId) throws EmployeeException {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empId);
	}

}
