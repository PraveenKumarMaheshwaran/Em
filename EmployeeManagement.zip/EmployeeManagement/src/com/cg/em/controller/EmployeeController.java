package com.cg.em.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.em.bean.EmployeeBean;
import com.cg.em.exception.EmployeeException;
import com.cg.em.service.EmployeeService;
import com.cg.em.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeService service;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeController() {
       
        service=new EmployeeServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		String action=request.getParameter("action");
		if("index".equals(action))
		{
			try{
			ArrayList<EmployeeBean> list=service.getAllData();
			session.setAttribute("list",list);
			RequestDispatcher dispatch=request.getRequestDispatcher("employee.jsp");
			dispatch.forward(request, response);
			}
			catch(EmployeeException e)
			{
				session.setAttribute("error",e.getMessage());
				response.sendRedirect("error.jsp");
			}
		}
		if("employee".equals(action))
		{
			String Id=request.getParameter("eid");
			int empId=Integer.parseInt(Id);
			session.setAttribute("empId", empId);
			RequestDispatcher dispatch=request.getRequestDispatcher("update.jsp");
			dispatch.forward(request, response);
			
		}
		
		if("employees".equals(action))
		{
			String Id=request.getParameter("id");
			int empId=Integer.parseInt(Id);
			session.setAttribute("empId", empId);
			RequestDispatcher dispatch=request.getRequestDispatcher("delete.jsp");
			dispatch.forward(request, response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		String action=request.getParameter("action");
		if("update".equals(action))
		{
			
			int empId=(int) session.getAttribute("empId");
			String sal=request.getParameter("newsal");
			int salary=Integer.parseInt(sal);
			try
			{
			EmployeeBean bean=service.updateSalary(empId,salary);


				session.setAttribute("bean", bean);
				response.sendRedirect("success.jsp");

			
			}
			catch(EmployeeException e)
			{
				session.setAttribute("error",e.getMessage());
				response.sendRedirect("error.jsp");
			}
		}
		
		if("delete".equals(action))
		{
			int empId=(int)session.getAttribute("empId");
			try{
			EmployeeBean bean=service.deleteEmp(empId);
			session.setAttribute("bean", bean);
			response.sendRedirect("success1.jsp");
			}
			catch(EmployeeException e)
			{
				session.setAttribute("error",e.getMessage());
				response.sendRedirect("error.jsp");
			}
		}
	}

}
